# custom-ner-with-spacy3
Custom Named Entity Recognition with Spacy3

Data Annotation using Free Open Source NER Annotator - https://tecoholic.github.io/ner-annotator/

Source Text: https://www.livemint.com/market/cryptocurrency/cryptocurrency-prices-today-bitcoin-ethereum-dogecoin-other-crypto-prices-surge-11639533539848.html

Tested Text: https://www.moneycontrol.com/news/business/markets/sp-500-dow-touch-record-highs-as-unemployment-claims-dip-7884431.html
